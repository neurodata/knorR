library(testthat)
library(knor)

test_check("knor")
