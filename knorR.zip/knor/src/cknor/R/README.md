# R-bindings

We provide an R interface for R. Please see
[https://github.com/flashxio/knorR](https://github.com/flashxio/knorR) for more
details.

# Docker

The `Dockerfile` contained in this directory is used to build a Linux image with
all OS and R dependencies for R bindings
